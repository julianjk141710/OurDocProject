<template>
  <div id="About">
    <h1>关于我: HeliantHuS</h1>
    <h1>QQ: 1984441370</h1>
    <h1>Bilibili: <a href="https://space.bilibili.com/178530124">https://space.bilibili.com/178530124</a></h1>
  </div>
</template>

<script>
  export default {
    name: 'About'
  }
</script>

<style scoped>

</style>
