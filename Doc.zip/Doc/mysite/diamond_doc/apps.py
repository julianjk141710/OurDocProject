from django.apps import AppConfig


class DiamondDocConfig(AppConfig):
    name = 'diamond_doc'
