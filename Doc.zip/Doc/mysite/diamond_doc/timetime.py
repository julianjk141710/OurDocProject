


sum = 0
for x in range(10):
    sum += x
print('************')
print(sum)