if type(1) is int:
    print(222)